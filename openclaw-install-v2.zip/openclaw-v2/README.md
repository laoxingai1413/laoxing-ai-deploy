# AI帮老板省人工 · 一键安装包 v2.0

## 这套系统能做什么？

| 功能 | 说明 |
|------|------|
| 🤖 飞书AI助理 | 在飞书直接对话，下达指令 |
| 🌐 联网搜索 | 实时搜索行业资讯、竞品信息 |
| 📄 文档摘要 | 长文档自动压缩成要点 |
| ⚙️ n8n自动化 | 定时任务、工作流自动执行 |
| 🖥️ 服务器监控 | 随时检查服务器健康状态 |

---

## 安装前准备

### 1. 服务器要求
- Linux系统（Ubuntu 20.04+ / CentOS 7+ / OpenCloudOS）
- 最低配置：2核 4G内存 50G硬盘
- 推荐：4核 8G内存（与老邢同款）

### 2. 需要准备的4个信息

| 信息 | 获取地址 |
|------|---------|
| 飞书 App ID | https://open.feishu.cn → 创建企业自建应用 |
| 飞书 App Secret | 同上 |
| 网关Token | 自定义密码，如 `MyAI2026` |
| 阿里云DashScope Key | https://dashscope.aliyun.com → API密钥 |

### 3. 飞书应用配置要点
1. 创建企业自建应用
2. 开通权限：`im:message`、`im:message:send_as_bot`、`cardkit:card:write`
3. 事件订阅 → 选择**长连接**模式
4. 发布应用

---

## 安装步骤

### 第一步：SSH连接服务器
```bash
ssh root@你的服务器IP
```

### 第二步：运行安装脚本
```bash
curl -fsSL https://raw.githubusercontent.com/你的仓库/main/install.sh | bash
```

按提示依次填入4个配置信息，等待3-5分钟自动完成。

### 第三步：测试
去飞书给机器人发消息：
```
你好，介绍一下你自己
```

---

## 安装后的目录结构

```
~/ai-system/
├── docker-compose.yml      # 服务编排文件
├── .env                    # 环境变量
├── openclaw-config/        # OpenClaw配置
│   └── openclaw.json
├── openclaw-workspace/     # 工作区
├── n8n-data/               # n8n数据
└── skills/                 # 已安装技能
    ├── xurl/
    ├── summarize/
    ├── healthcheck/
    └── weather/
```

---

## 常用命令

```bash
# 查看服务状态
cd ~/ai-system && docker compose ps

# 重启服务
cd ~/ai-system && docker compose restart

# 查看日志
docker logs openclaw-gateway --tail 50

# 访问n8n（需要先建SSH隧道）
ssh -L 5678:127.0.0.1:5678 root@服务器IP
# 然后浏览器打开 http://localhost:5678
```

---

## 技术支持

有问题联系老邢AI工作室。
